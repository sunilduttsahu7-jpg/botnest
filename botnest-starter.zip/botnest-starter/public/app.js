const $ = (s) => document.querySelector(s);
const modal = $('#modal');
let activities = [];
function toast(message) { const el = $('#toast'); el.textContent = message; el.classList.add('show'); clearTimeout(toast.timer); toast.timer = setTimeout(() => el.classList.remove('show'), 2800); }
function addActivity(message) { activities.unshift({ message, time: new Date() }); activities = activities.slice(0, 5); renderActivity(); }
function renderActivity() {
  const host = $('#activity-list');
  if (!activities.length) { host.className = 'activity-empty'; host.innerHTML = '<span class="activity-symbol">◷</span><span>Your activity will show up here as you build.</span>'; return; }
  host.className = 'activity-items';
  host.innerHTML = activities.map(a => `<div class="bot-row"><div class="activity-symbol">✦</div><div class="bot-info"><strong>${escapeHtml(a.message)}</strong><div class="bot-meta">${a.time.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'})} · just now</div></div></div>`).join('');
}
function escapeHtml(s) { return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
function openModal() { modal.hidden = false; $('#bot-name').focus(); }
function closeModal() { modal.hidden = true; $('#form-error').textContent = ''; $('#create-form').reset(); }
$('#new-bot').addEventListener('click', openModal);
$('#empty-create').addEventListener('click', openModal);
$('#close-modal').addEventListener('click', closeModal);
modal.addEventListener('click', e => { if (e.target === modal) closeModal(); });
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeModal(); });
$('#guide').addEventListener('click', () => { document.querySelector('#quickstart').scrollIntoView({behavior:'smooth', block:'center'}); toast('Quick start: create a project, upload a ZIP, then configure the secure runner.'); });
$('#refresh').addEventListener('click', loadBots);
$('#search').addEventListener('input', loadBots);

async function loadBots() {
  try {
    const res = await fetch('/api/bots');
    if (!res.ok) throw new Error('Could not load bots');
    const bots = await res.json();
    renderBots(bots);
  } catch { toast('Could not reach BotNest API. Is the server running?'); }
}
function renderBots(bots) {
  const query = $('#search').value.trim().toLowerCase();
  const filtered = bots.filter(b => b.name.toLowerCase().includes(query));
  $('#total-bots').innerHTML = `${bots.length} <small>bots</small>`;
  $('#running-bots').innerHTML = `${bots.filter(b => b.status === 'running').length} <small>bots</small>`;
  $('#nav-count').textContent = bots.length;
  const host = $('#bot-list');
  if (!filtered.length && !query) {
    host.innerHTML = '<div class="empty-state"><div class="empty-graphic"><span>✦</span><div class="empty-cube">⬡</div><i></i></div><h3>Your next great bot starts here.</h3><p>Create a project, upload your files, and get everything ready for deployment.</p><button class="primary-button small" id="empty-create">＋ Create your first bot</button></div>';
    $('#empty-create').addEventListener('click', openModal); return;
  }
  if (!filtered.length) { host.innerHTML = '<div class="activity-empty">No bots match that search.</div>'; return; }
  host.innerHTML = filtered.map(b => `<div class="bot-row"><div class="bot-avatar">${b.runtime === 'python' ? 'Py' : '⌘'}</div><div class="bot-info"><strong>${escapeHtml(b.name)}</strong><div class="bot-meta"><span class="runtime-tag">${b.runtime === 'python' ? 'Python' : 'Node.js'}</span><span>${b.uploaded ? 'ZIP uploaded' : 'Project created'}</span></div></div><span class="bot-status">${escapeHtml(b.status.replaceAll('-', ' '))}</span><button class="delete-bot" data-delete="${b.id}" title="Delete project">×</button></div>`).join('');
  host.querySelectorAll('[data-delete]').forEach(btn => btn.addEventListener('click', async () => {
    if (!confirm('Delete this BotNest project and its stored ZIP?')) return;
    const res = await fetch(`/api/bots/${btn.dataset.delete}`, {method:'DELETE'});
    if (res.ok) { addActivity('Project deleted'); toast('Project deleted.'); await loadBots(); }
    else toast('Could not delete project.');
  }));
}
$('#create-form').addEventListener('submit', async e => {
  e.preventDefault();
  const button = $('.modal-submit'); button.disabled = true; button.textContent = 'Creating…';
  try {
    const res = await fetch('/api/bots', { method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({name:$('#bot-name').value, runtime:$('#runtime').value}) });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error || 'Could not create project');
    closeModal(); addActivity(`Created ${data.name}`); toast(`${data.name} is ready for files.`); await loadBots();
  } catch (err) { $('#form-error').textContent = err.message; }
  finally { button.disabled = false; button.innerHTML = 'Create project <span>→</span>'; }
});
fetch('/api/health').then(r => r.json()).then(data => { if (!data.ok) throw new Error(); }).catch(() => { $('.status-pill').innerHTML = '<i style="background:#e7b35a;box-shadow:none"></i> API offline'; });
loadBots();
