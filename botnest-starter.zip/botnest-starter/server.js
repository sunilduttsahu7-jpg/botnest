'use strict';

const express = require('express');
const helmet = require('helmet');
const multer = require('multer');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');

const app = express();
const PORT = Number(process.env.PORT || 3000);
const HOST = process.env.HOST || '127.0.0.1'; // Local-only until authentication is implemented.
const ROOT = __dirname;
const DATA_DIR = path.join(ROOT, 'data');
const UPLOAD_DIR = path.join(ROOT, 'uploads');
const DB_FILE = path.join(DATA_DIR, 'bots.json');
fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, '[]\n');

app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: '32kb' }));
app.use(express.static(path.join(ROOT, 'public')));

function readBots() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, 'utf8')); }
  catch { return []; }
}
function writeBots(bots) {
  const tmp = `${DB_FILE}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(bots, null, 2));
  fs.renameSync(tmp, DB_FILE);
}
function publicBot(bot) {
  const { uploadPath, ...safe } = bot;
  return safe;
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => cb(null, `${crypto.randomUUID()}.zip`)
});
const upload = multer({
  storage,
  limits: { fileSize: 10 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const valid = path.extname(file.originalname).toLowerCase() === '.zip' &&
      (file.mimetype === 'application/zip' || file.mimetype === 'application/x-zip-compressed' || file.mimetype === 'application/octet-stream');
    cb(valid ? null : new Error('Upload a .zip file only.'), valid);
  }
});

app.get('/api/health', (_req, res) => res.json({ ok: true, service: 'botnest-api', hostingRuntime: 'not-configured' }));
app.get('/api/bots', (_req, res) => res.json(readBots().map(publicBot)));

app.post('/api/bots', (req, res) => {
  const name = String(req.body?.name || '').trim();
  const runtime = String(req.body?.runtime || '').trim().toLowerCase();
  if (name.length < 2 || name.length > 40) return res.status(400).json({ error: 'Bot name must be 2–40 characters.' });
  if (!['node', 'python'].includes(runtime)) return res.status(400).json({ error: 'Runtime must be node or python.' });
  const bots = readBots();
  const bot = {
    id: crypto.randomUUID(), name, runtime, status: 'not-deployed',
    createdAt: new Date().toISOString(), uploaded: false,
    note: 'Files can be stored in this starter; isolated runtime is not enabled yet.'
  };
  bots.unshift(bot);
  writeBots(bots);
  res.status(201).json(publicBot(bot));
});

app.post('/api/bots/:id/upload', (req, res, next) => {
  const bots = readBots();
  const bot = bots.find(item => item.id === req.params.id);
  if (!bot) return res.status(404).json({ error: 'Bot not found.' });
  upload.single('file')(req, res, err => {
    if (err) return res.status(400).json({ error: err.message || 'Upload failed.' });
    if (!req.file) return res.status(400).json({ error: 'Choose a .zip file.' });
    bot.uploaded = true;
    bot.uploadName = path.basename(req.file.originalname).slice(0, 120);
    bot.uploadPath = req.file.path;
    bot.status = 'uploaded';
    bot.note = 'Upload stored. It has NOT been extracted or executed.';
    writeBots(bots);
    res.json(publicBot(bot));
  });
});

app.delete('/api/bots/:id', (req, res) => {
  const bots = readBots();
  const bot = bots.find(item => item.id === req.params.id);
  if (!bot) return res.status(404).json({ error: 'Bot not found.' });
  if (bot.uploadPath && path.dirname(path.resolve(bot.uploadPath)) === path.resolve(UPLOAD_DIR)) {
    try { fs.unlinkSync(bot.uploadPath); } catch {}
  }
  writeBots(bots.filter(item => item.id !== req.params.id));
  res.status(204).end();
});

app.use((err, _req, res, _next) => {
  console.error(err.message);
  res.status(500).json({ error: 'Unexpected server error.' });
});

app.listen(PORT, HOST, () => {
  console.log(`BotNest starter running at http://${HOST}:${PORT}`);
  console.log('Safety mode: local-only; uploaded code is stored, never executed.');
});
