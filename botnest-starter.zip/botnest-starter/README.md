# BotNest — Foundation build (0.1.0)

A dark purple/blue dashboard foundation for a Discord bot hosting platform. It currently supports project creation (Node.js/Python metadata), listing/searching projects, deletion, and storing a ZIP upload (max 10 MB). **Uploaded code is never extracted or executed in this foundation build.**

## Requirements
- Node.js 20.9 or newer
- npm

## Run locally

```bash
npm install
npm start
```

Open <http://127.0.0.1:3000>.

The server binds to `127.0.0.1` by default on purpose. Do not expose this starter to the internet as-is: it does not yet have user authentication, Discord OAuth, CSRF protection, per-user authorization, quotas, or an isolated bot runner.

## API endpoints

- `GET /api/health` — health status
- `GET /api/bots` — list projects
- `POST /api/bots` — JSON body `{ "name": "My Bot", "runtime": "node" }` or `python`
- `POST /api/bots/:id/upload` — multipart form field `file`, ZIP only, max 10 MB
- `DELETE /api/bots/:id` — delete project and stored upload

Project metadata is stored in `data/bots.json`; uploads are stored under `uploads/`. Do not put secrets or bot tokens into uploaded ZIP files.

## Roadmap to real hosting

1. **Identity & ownership:** Discord OAuth2 login, secure server-side sessions, CSRF protection, and every API query scoped to the signed-in owner.
2. **Upload pipeline:** verify archive contents, reject path traversal/symlinks, scan files, unpack into a per-project directory with strict size/file-count limits.
3. **Runner service:** a separate privileged-control service that starts each bot in its own isolated container. Never mount the Docker socket into the public web app. Use a narrow internal runner API, strict authentication, allowlisted runtime images, CPU/memory/PID/disk limits, read-only base filesystem where possible, non-root UID, dropped Linux capabilities, seccomp/AppArmor, no privileged mode, and controlled network egress.
4. **Secrets:** encrypted environment-variable storage; redact tokens from logs; never return secrets to the browser after saving.
5. **Lifecycle:** start/stop/restart, health checks, bounded log streaming, crash/restart policy, per-user quotas and cleanup.
6. **Production:** HTTPS/reverse proxy, rate limits, backups, monitoring, audit logs, firewall rules, patched OS/runtime images, and abuse reporting.
7. **Discord integration:** optional Discord OAuth login and bot invite link. Users create bot applications in the Discord Developer Portal; BotNest hosts their code, it does not mint Discord bot tokens.

### Hosting safety note
User-uploaded programs are untrusted code. Containerization alone is not a complete security boundary. For a public multi-user service, review the isolation model and consider stronger sandboxing (for example, gVisor or a dedicated worker VM) before accepting arbitrary code. Docker's official security guidance: https://docs.docker.com/engine/security/ and rootless mode: https://docs.docker.com/engine/security/rootless/.

## Current limitations
- No real process runner is connected; the dashboard deliberately shows runtime as not configured.
- No Discord OAuth/login yet.
- The JSON file store is suitable only for a local prototype, not concurrent production use.
- ZIP upload is storage-only and is not safe to expose publicly without authentication and further upload validation.
